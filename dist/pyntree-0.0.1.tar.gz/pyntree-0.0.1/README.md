# pyntree
A new Node Database system in Python based off of pyndb but written from scratch. Open to name suggestions.
WARNING: CURRENTLY IN AN ALPHA STATE!

## Project board
To view, visit https://board.jvadair.com
and use credentials:
- Username: public
- Password: public

## Docs
The external documentation is not finished yet, but I have made sure to add detailed in-code documentation.

To view the *WIP* documentation, visit: https://pen.jvadair.com/books/pyntree

> Do not expect any level of correctness or completeness from the documentation yet.

## Contributing
If you would like to contribute, feel free to fork the repository and start a pull request. I will manually review/test them before implementing. If you have any questions regarding the project or how to contribute, you're welcome to [contact me](mailto:dev@jvadair.com).
